const { logInfo } = require('./utils');

class SignalGenerator {
    constructor() {
        this.signalHistory = [];
        this.maxHistorySize = 10;
        this.trend = 'neutral';
        this.trendStrength = 0;
        
        // Most traded forex pairs with starting prices
        this.tradingPairs = {
            'EUR/USD': { price: 1.0850, volatility: 0.008 },
            'GBP/USD': { price: 1.2650, volatility: 0.012 },
            'USD/JPY': { price: 149.50, volatility: 0.010 },
            'USD/CHF': { price: 0.8950, volatility: 0.009 },
            'AUD/USD': { price: 0.6750, volatility: 0.011 },
            'USD/CAD': { price: 1.3550, volatility: 0.008 },
            'NZD/USD': { price: 0.6150, volatility: 0.013 },
            'EUR/GBP': { price: 0.8580, volatility: 0.007 },
            'EUR/JPY': { price: 162.25, volatility: 0.011 },
            'GBP/JPY': { price: 189.15, volatility: 0.015 },
            'XAU/USD': { price: 2050.00, volatility: 0.020 }, // Gold/USD
            'XAU/EUR': { price: 1950.00, volatility: 0.018 }  // Gold/EUR
        };
        
        this.currentPair = 'XAU/EUR'; // Default pair
    }

    generateSignal(requestedPair = null) {
        const timestamp = new Date();
        
        // Select trading pair - either requested or random popular pair
        const pair = requestedPair || this.selectRandomPair();
        this.currentPair = pair;
        
        // Get current price for this pair
        const currentPrice = this.tradingPairs[pair].price;
        
        // Simulate market movement with some randomness but following trends
        const priceMovement = this.calculatePriceMovement(pair);
        this.tradingPairs[pair].price += priceMovement;
        
        // Update trend based on recent movements
        this.updateTrend(priceMovement);
        
        // Generate signal based on technical analysis simulation
        const signal = this.analyzeMarket(pair);
        
        const fullSignal = {
            id: this.generateSignalId(),
            timestamp: timestamp,
            pair: pair,
            signal: signal.action,
            entryPrice: this.tradingPairs[pair].price,
            stopLoss: signal.stopLoss,
            takeProfit1: signal.takeProfit1,
            takeProfit2: signal.takeProfit2,
            confidence: signal.confidence,
            timeframe: '15M',
            analysis: signal.analysis
        };

        // Add to history
        this.addToHistory(fullSignal);
        
        logInfo('Generated signal:', fullSignal);
        return fullSignal;
    }

    selectRandomPair() {
        const pairs = Object.keys(this.tradingPairs);
        // Weight popular pairs more heavily
        const popularPairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'XAU/USD', 'XAU/EUR'];
        const weightedPairs = [...pairs, ...popularPairs];
        return weightedPairs[Math.floor(Math.random() * weightedPairs.length)];
    }

    calculatePriceMovement(pair) {
        const pairData = this.tradingPairs[pair];
        const basePrice = pairData.price;
        const volatility = pairData.volatility;
        
        // Base random movement based on pair's volatility
        const baseMovement = (Math.random() - 0.5) * basePrice * volatility * 2;
        
        // Trend influence
        const trendInfluence = this.trendStrength * (this.trend === 'bullish' ? 1 : -1) * basePrice * volatility;
        
        // Market volatility factor
        const volatilityFactor = 1 + (Math.random() * 0.5); // 1.0 to 1.5
        
        return (baseMovement + trendInfluence) * volatilityFactor;
    }

    updateTrend(movement) {
        // Update trend strength based on movement direction
        if ((this.trend === 'bullish' && movement > 0) || (this.trend === 'bearish' && movement < 0)) {
            this.trendStrength = Math.min(this.trendStrength + 0.1, 1.0);
        } else if ((this.trend === 'bullish' && movement < 0) || (this.trend === 'bearish' && movement > 0)) {
            this.trendStrength = Math.max(this.trendStrength - 0.2, 0);
        }

        // Change trend if strength is low and movement is significant
        if (this.trendStrength < 0.3) {
            if (movement > 5) {
                this.trend = 'bullish';
                this.trendStrength = 0.4;
            } else if (movement < -5) {
                this.trend = 'bearish';
                this.trendStrength = 0.4;
            } else {
                this.trend = 'neutral';
                this.trendStrength = 0;
            }
        }
    }

    analyzeMarket(pair) {
        const signals = ['BUY', 'SELL', 'HOLD'];
        let action, confidence, analysis;

        // Technical analysis simulation
        const rsiValue = 30 + (Math.random() * 40); // RSI between 30-70
        const macdSignal = Math.random() > 0.5 ? 'bullish' : 'bearish';
        const supportResistance = this.calculateSupportResistance(pair);

        // Determine signal based on multiple factors
        if (this.trend === 'bullish' && rsiValue < 40 && macdSignal === 'bullish') {
            action = 'BUY';
            confidence = Math.min(85 + Math.random() * 10, 95);
            analysis = `Strong bullish momentum. RSI: ${rsiValue.toFixed(1)}, MACD: Bullish crossover, Trend: ${this.trend}`;
        } else if (this.trend === 'bearish' && rsiValue > 60 && macdSignal === 'bearish') {
            action = 'SELL';
            confidence = Math.min(85 + Math.random() * 10, 95);
            analysis = `Strong bearish momentum. RSI: ${rsiValue.toFixed(1)}, MACD: Bearish crossover, Trend: ${this.trend}`;
        } else if (rsiValue > 70) {
            action = 'SELL';
            confidence = 60 + Math.random() * 20;
            analysis = `Overbought conditions. RSI: ${rsiValue.toFixed(1)}, Consider taking profits`;
        } else if (rsiValue < 30) {
            action = 'BUY';
            confidence = 60 + Math.random() * 20;
            analysis = `Oversold conditions. RSI: ${rsiValue.toFixed(1)}, Potential reversal`;
        } else {
            action = 'HOLD';
            confidence = 40 + Math.random() * 20;
            analysis = `Consolidation phase. RSI: ${rsiValue.toFixed(1)}, Wait for clearer signals`;
        }

        // Calculate stop loss and take profit levels
        const stopLoss = this.calculateStopLoss(action, pair);
        const takeProfits = this.calculateTakeProfits(action, pair);

        return {
            action,
            confidence: Math.round(confidence),
            analysis,
            stopLoss,
            takeProfit1: takeProfits.tp1,
            takeProfit2: takeProfits.tp2,
            supportResistance
        };
    }

    calculateSupportResistance(pair) {
        const currentPrice = this.tradingPairs[pair].price;
        const volatility = this.tradingPairs[pair].volatility;
        const range = currentPrice * volatility * 10;
        
        return {
            support: currentPrice - (range * 0.8 + Math.random() * range * 0.4),
            resistance: currentPrice + (range * 0.8 + Math.random() * range * 0.4)
        };
    }

    calculateStopLoss(action, pair) {
        const currentPrice = this.tradingPairs[pair].price;
        const volatility = this.tradingPairs[pair].volatility;
        const stopLossDistance = currentPrice * volatility * (3 + Math.random() * 2); // Dynamic based on pair volatility
        
        if (action === 'BUY') {
            return currentPrice - stopLossDistance;
        } else if (action === 'SELL') {
            return currentPrice + stopLossDistance;
        }
        return null;
    }

    calculateTakeProfits(action, pair) {
        const currentPrice = this.tradingPairs[pair].price;
        const volatility = this.tradingPairs[pair].volatility;
        const tp1Distance = currentPrice * volatility * (2 + Math.random() * 1.5);
        const tp2Distance = currentPrice * volatility * (4 + Math.random() * 2);

        if (action === 'BUY') {
            return {
                tp1: currentPrice + tp1Distance,
                tp2: currentPrice + tp2Distance
            };
        } else if (action === 'SELL') {
            return {
                tp1: currentPrice - tp1Distance,
                tp2: currentPrice - tp2Distance
            };
        }
        return { tp1: null, tp2: null };
    }

    generateSignalId() {
        return 'XAU' + Date.now().toString(36).toUpperCase();
    }

    addToHistory(signal) {
        this.signalHistory.unshift(signal);
        if (this.signalHistory.length > this.maxHistorySize) {
            this.signalHistory.pop();
        }
    }

    getHistory() {
        return [...this.signalHistory];
    }

    getLatestSignal() {
        return this.signalHistory[0] || null;
    }

    getCurrentPrice(pair = null) {
        const targetPair = pair || this.currentPair;
        return this.tradingPairs[targetPair].price;
    }

    getTrendInfo() {
        return {
            trend: this.trend,
            strength: this.trendStrength,
            price: this.tradingPairs[this.currentPair].price,
            currentPair: this.currentPair
        };
    }

    getAllPairs() {
        return Object.keys(this.tradingPairs);
    }

    setPair(pair) {
        if (this.tradingPairs[pair]) {
            this.currentPair = pair;
            return true;
        }
        return false;
    }
}

module.exports = SignalGenerator;
