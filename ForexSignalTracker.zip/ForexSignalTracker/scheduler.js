const cron = require('node-cron');
const SignalGenerator = require('./signalGenerator');
const { logInfo, logError } = require('./utils');

class Scheduler {
    constructor(bot) {
        this.bot = bot;
        this.signalGenerator = new SignalGenerator();
        this.job = null;
        this.isRunning = false;
    }

    start(broadcastCallback) {
        if (this.isRunning) {
            logInfo('Scheduler is already running');
            return;
        }

        // Schedule to run every 15 minutes
        // Cron format: minute hour day month day-of-week
        // */15 * * * * means every 15 minutes
        this.job = cron.schedule('*/15 * * * *', () => {
            this.executeScheduledTask(broadcastCallback);
        }, {
            scheduled: true,
            timezone: "UTC"
        });

        this.isRunning = true;
        logInfo('Signal scheduler started - signals will be sent every 15 minutes');
        
        // Send initial signal after 1 minute to test the system
        setTimeout(() => {
            this.executeScheduledTask(broadcastCallback);
        }, 60000); // 1 minute delay
    }

    stop() {
        if (this.job) {
            this.job.stop();
            this.job = null;
        }
        this.isRunning = false;
        logInfo('Signal scheduler stopped');
    }

    async executeScheduledTask(broadcastCallback) {
        try {
            logInfo('Executing scheduled signal generation...');
            
            // Check if it's market hours (optional - forex markets are 24/5)
            if (!this.isMarketHours()) {
                logInfo('Outside market hours, skipping signal generation');
                return;
            }

            const signal = this.signalGenerator.generateSignal();
            
            if (broadcastCallback && typeof broadcastCallback === 'function') {
                broadcastCallback(signal);
            }
            
            logInfo(`Scheduled signal generated and broadcasted: ${signal.signal} at ${signal.entryPrice}`);
        } catch (error) {
            logError('Error in scheduled task execution:', error);
        }
    }

    isMarketHours() {
        const now = new Date();
        const utcDay = now.getUTCDay(); // 0 = Sunday, 6 = Saturday
        const utcHour = now.getUTCHours();
        
        // Forex market is closed on weekends
        // Friday 22:00 UTC to Sunday 22:00 UTC is typically closed
        if (utcDay === 0 && utcHour < 22) { // Sunday before 22:00 UTC
            return false;
        }
        if (utcDay === 6 && utcHour >= 22) { // Saturday after 22:00 UTC
            return false;
        }
        
        // During week days, market is generally open 24 hours
        return true;
    }

    getNextSignalTime() {
        if (!this.isRunning) {
            return null;
        }

        const now = new Date();
        const currentMinutes = now.getMinutes();
        const nextQuarter = Math.ceil((currentMinutes + 1) / 15) * 15;
        
        const nextTime = new Date(now);
        if (nextQuarter >= 60) {
            nextTime.setHours(nextTime.getHours() + 1);
            nextTime.setMinutes(nextQuarter - 60);
        } else {
            nextTime.setMinutes(nextQuarter);
        }
        nextTime.setSeconds(0);
        nextTime.setMilliseconds(0);

        return nextTime;
    }

    getSchedulerStatus() {
        return {
            isRunning: this.isRunning,
            nextSignalTime: this.getNextSignalTime(),
            isMarketHours: this.isMarketHours(),
            totalSignalsGenerated: this.signalGenerator.getHistory().length
        };
    }

    // Manual trigger for testing
    async triggerManualSignal(broadcastCallback) {
        logInfo('Manual signal trigger requested');
        await this.executeScheduledTask(broadcastCallback);
    }
}

module.exports = Scheduler;
