const fs = require('fs');
const path = require('path');

// Logging utilities
function logInfo(message, data = null) {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] INFO: ${message}`, data || '');
}

function logError(message, error = null) {
    const timestamp = new Date().toISOString();
    console.error(`[${timestamp}] ERROR: ${message}`, error || '');
}

function logWarn(message, data = null) {
    const timestamp = new Date().toISOString();
    console.warn(`[${timestamp}] WARN: ${message}`, data || '');
}

// Signal formatting utility
function formatSignal(signal) {
    const signalEmoji = {
        'BUY': '🟢',
        'SELL': '🔴',
        'HOLD': '🟡'
    };

    const emoji = signalEmoji[signal.signal] || '⚪';
    const confidenceBar = generateConfidenceBar(signal.confidence);
    
    let formattedMessage = `
${emoji} *XAU/EUR TRADING SIGNAL* ${emoji}

🎯 *Action:* ${signal.signal}
💰 *Entry Price:* ${signal.entryPrice.toFixed(2)} EUR
📊 *Confidence:* ${signal.confidence}% ${confidenceBar}
⏰ *Time:* ${formatTime(signal.timestamp)}
📋 *Signal ID:* ${signal.id}

📈 *Targets & Risk Management:*
`;

    if (signal.stopLoss) {
        formattedMessage += `🛡 *Stop Loss:* ${signal.stopLoss.toFixed(2)} EUR\n`;
    }
    
    if (signal.takeProfit1) {
        formattedMessage += `🎯 *Take Profit 1:* ${signal.takeProfit1.toFixed(2)} EUR\n`;
    }
    
    if (signal.takeProfit2) {
        formattedMessage += `🎯 *Take Profit 2:* ${signal.takeProfit2.toFixed(2)} EUR\n`;
    }

    formattedMessage += `
📊 *Technical Analysis:*
${signal.analysis}

⚠️ *Risk Warning:* Trading involves risk. Never risk more than you can afford to lose.

*Timeframe:* ${signal.timeframe} | *Pair:* ${signal.pair}
    `;

    return formattedMessage.trim();
}

function generateConfidenceBar(confidence) {
    const bars = Math.round(confidence / 10);
    const filledBars = '🟩'.repeat(bars);
    const emptyBars = '⬜'.repeat(10 - bars);
    return filledBars + emptyBars;
}

function formatTime(timestamp) {
    return timestamp.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'UTC',
        timeZoneName: 'short'
    });
}

// Price formatting utilities
function formatPrice(price, decimals = 2) {
    return Number(price).toFixed(decimals);
}

function formatPercentage(value, decimals = 1) {
    return `${Number(value).toFixed(decimals)}%`;
}

// Date utilities
function getTimestamp() {
    return new Date().toISOString();
}

function isWeekend() {
    const day = new Date().getDay();
    return day === 0 || day === 6; // Sunday = 0, Saturday = 6
}

function isMarketOpen() {
    const now = new Date();
    const utcDay = now.getUTCDay();
    const utcHour = now.getUTCHours();
    
    // Basic forex market hours check
    if (utcDay === 0 && utcHour < 22) return false; // Sunday before 22:00 UTC
    if (utcDay === 6 && utcHour >= 22) return false; // Saturday after 22:00 UTC
    
    return true;
}

// Data validation utilities
function validateSignal(signal) {
    const requiredFields = ['signal', 'entryPrice', 'confidence', 'timestamp'];
    const validSignals = ['BUY', 'SELL', 'HOLD'];
    
    for (const field of requiredFields) {
        if (!signal.hasOwnProperty(field)) {
            throw new Error(`Missing required field: ${field}`);
        }
    }
    
    if (!validSignals.includes(signal.signal)) {
        throw new Error(`Invalid signal type: ${signal.signal}`);
    }
    
    if (signal.confidence < 0 || signal.confidence > 100) {
        throw new Error(`Invalid confidence value: ${signal.confidence}`);
    }
    
    return true;
}

// Environment utilities
function getEnvVar(name, defaultValue = null) {
    const value = process.env[name];
    if (!value && defaultValue === null) {
        throw new Error(`Environment variable ${name} is required`);
    }
    return value || defaultValue;
}

// Error handling utilities
function handleBotError(error, context = '') {
    logError(`Bot error ${context}:`, error);
    
    // Handle specific Telegram API errors
    if (error.response) {
        const { statusCode, body } = error.response;
        logError(`Telegram API Error - Status: ${statusCode}, Body:`, body);
        
        if (statusCode === 429) {
            logWarn('Rate limit exceeded, backing off...');
        } else if (statusCode === 403) {
            logWarn('Bot blocked by user or chat');
        }
    }
}

// File utilities
function ensureDirectoryExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        logInfo(`Created directory: ${dirPath}`);
    }
}

// Configuration utilities
function loadConfig() {
    return {
        telegramToken: getEnvVar('TELEGRAM_BOT_TOKEN'),
        signalInterval: getEnvVar('SIGNAL_INTERVAL_MINUTES', '15'),
        maxHistorySize: getEnvVar('MAX_HISTORY_SIZE', '10'),
        timezone: getEnvVar('TIMEZONE', 'UTC'),
        logLevel: getEnvVar('LOG_LEVEL', 'info')
    };
}

module.exports = {
    logInfo,
    logError,
    logWarn,
    formatSignal,
    generateConfidenceBar,
    formatTime,
    formatPrice,
    formatPercentage,
    getTimestamp,
    isWeekend,
    isMarketOpen,
    validateSignal,
    getEnvVar,
    handleBotError,
    ensureDirectoryExists,
    loadConfig
};
