const SignalGenerator = require('./signalGenerator');
const { formatSignal, formatTime, logError, logInfo } = require('./utils');

class Commands {
    constructor(bot) {
        this.bot = bot;
        this.signalGenerator = new SignalGenerator();
    }

    async handleStart(chatId, msg) {
        const welcomeMessage = `
🌟 *Welcome to Multi-Pair Forex Signals Bot!* 🌟

I provide professional forex trading signals for 12 major currency pairs and commodities every 15 minutes to help you make informed trading decisions.

*Available Commands:*
/help - Show this help message
/signals [pair] - Get trading signal (e.g. /signals EUR/USD)
/pairs - View all available trading pairs
/history - View recent signal history
/subscribe - Subscribe to automated signals
/unsubscribe - Unsubscribe from automated signals
/status - Check bot and market status

*Features:*
📊 12 major forex pairs + gold commodities
⏰ Signals every 15 minutes
🎯 Entry points with Stop Loss & Take Profit
📈 Technical analysis with RSI & MACD
📱 Professional signal formatting
🎲 Random or specific pair selection

Type /pairs to see all available pairs or /signals to get started!
        `;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: '📊 Get Signal', callback_data: 'get_signal' },
                    { text: '💱 Trading Pairs', callback_data: 'pairs' }
                ],
                [
                    { text: '🔔 Subscribe', callback_data: 'subscribe' },
                    { text: '📈 History', callback_data: 'history' }
                ]
            ]
        };

        try {
            await this.bot.sendMessage(chatId, welcomeMessage, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        } catch (error) {
            logError('Error sending start message:', error);
        }
    }

    async handleHelp(chatId) {
        const helpMessage = `
📖 *Multi-Pair Forex Signals Bot Help*

*Commands:*
/start - Welcome message and main menu
/signals [pair] - Get signal for specific pair (e.g. /signals EUR/USD)
/pairs - View all 12 available trading pairs
/history - View last 10 signals
/subscribe - Enable automated signals (every 15 min)
/unsubscribe - Disable automated signals
/status - Bot and market status

*Signal Information:*
• **BUY/SELL/HOLD** - Trading recommendation
• **Entry Price** - Suggested entry point
• **Stop Loss** - Risk management level
• **Take Profit 1 & 2** - Profit targets
• **Confidence** - Signal strength (%)
• **Analysis** - Technical analysis summary

*Available Pairs:*
• **Majors:** EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, NZD/USD
• **Crosses:** EUR/GBP, EUR/JPY, GBP/JPY
• **Commodities:** XAU/USD (Gold/Dollar), XAU/EUR (Gold/Euro)

*Disclaimer:*
Signals are for educational purposes. Always do your own research and manage risk appropriately.

For support: Contact @YourTelegramSupport
        `;

        try {
            await this.bot.sendMessage(chatId, helpMessage, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            logError('Error sending help message:', error);
        }
    }

    async handleSignals(chatId, args = []) {
        try {
            await this.bot.sendChatAction(chatId, 'typing');
            
            // Check if user specified a trading pair
            const requestedPair = args[0]?.toUpperCase();
            const availablePairs = this.signalGenerator.getAllPairs();
            
            if (requestedPair && !availablePairs.includes(requestedPair)) {
                await this.bot.sendMessage(chatId, 
                    `❌ Trading pair "${requestedPair}" not found.\n\nUse /pairs to see all available pairs.`);
                return;
            }
            
            const signal = this.signalGenerator.generateSignal(requestedPair);
            await this.sendSignal(chatId, signal);
        } catch (error) {
            logError('Error handling signals command:', error);
            await this.bot.sendMessage(chatId, '❌ Sorry, there was an error generating the signal. Please try again.');
        }
    }

    async sendSignal(chatId, signal) {
        const formattedSignal = formatSignal(signal);
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: '🔄 New Signal', callback_data: 'get_signal' },
                    { text: '📈 History', callback_data: 'history' }
                ]
            ]
        };

        try {
            await this.bot.sendMessage(chatId, formattedSignal, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        } catch (error) {
            logError('Error sending signal:', error);
            throw error;
        }
    }

    async handleHistory(chatId) {
        try {
            const history = this.signalGenerator.getHistory();
            
            if (history.length === 0) {
                await this.bot.sendMessage(chatId, '📝 No signal history available yet. Generate your first signal with /signals');
                return;
            }

            let historyMessage = '📊 *Recent Signal History*\n\n';
            
            history.slice(0, 5).forEach((signal, index) => {
                const timeAgo = this.getTimeAgo(signal.timestamp);
                const emoji = signal.signal === 'BUY' ? '🟢' : signal.signal === 'SELL' ? '🔴' : '🟡';
                
                historyMessage += `${emoji} *${signal.signal}* - ${signal.confidence}%\n`;
                historyMessage += `💰 ${signal.entryPrice.toFixed(2)} EUR\n`;
                historyMessage += `⏱ ${timeAgo}\n`;
                historyMessage += `📋 ID: ${signal.id}\n\n`;
            });

            historyMessage += `\n💡 Showing last ${Math.min(5, history.length)} signals`;
            historyMessage += `\nTotal signals generated: ${history.length}`;

            await this.bot.sendMessage(chatId, historyMessage, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            logError('Error handling history command:', error);
            await this.bot.sendMessage(chatId, '❌ Error retrieving signal history.');
        }
    }

    async handleSubscribe(chatId) {
        // In a real implementation, you would save this to a database
        const message = `
🔔 *Subscription Activated!*

You will now receive XAU/EUR trading signals automatically every 15 minutes.

*What you'll receive:*
• Professional trading signals
• Technical analysis
• Entry points and targets
• Risk management levels

*Signal Schedule:*
Every 15 minutes during market hours

Use /unsubscribe to stop receiving automated signals.
Use /status to check your subscription status.
        `;

        try {
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
            logInfo(`User ${chatId} subscribed to signals`);
        } catch (error) {
            logError('Error handling subscribe command:', error);
        }
    }

    async handleUnsubscribe(chatId) {
        const message = `
🔕 *Subscription Deactivated*

You will no longer receive automated XAU/EUR trading signals.

You can still:
• Use /signals to get manual signals
• Use /history to view past signals
• Use /subscribe to reactivate notifications

Thank you for using our service!
        `;

        try {
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
            logInfo(`User ${chatId} unsubscribed from signals`);
        } catch (error) {
            logError('Error handling unsubscribe command:', error);
        }
    }

    async handleStatus(chatId) {
        try {
            const trendInfo = this.signalGenerator.getTrendInfo();
            const latestSignal = this.signalGenerator.getLatestSignal();
            const uptime = process.uptime();
            
            let statusMessage = `
🤖 *Bot Status Report*

*System Status:* ✅ Online
*Uptime:* ${this.formatUptime(uptime)}
*Last Signal:* ${latestSignal ? formatTime(latestSignal.timestamp) : 'None yet'}

*Market Status:*
💹 *Current XAU/EUR:* ${trendInfo.price.toFixed(2)} EUR
📈 *Trend:* ${this.formatTrend(trendInfo.trend)} (${Math.round(trendInfo.strength * 100)}%)
⏰ *Next Signal:* Within 15 minutes
🎯 *Signal Frequency:* Every 15 minutes

*Performance:*
📊 Total Signals Generated: ${this.signalGenerator.getHistory().length}
📱 Active Features: All systems operational

*Subscription Status:* 🔔 Active
            `;

            await this.bot.sendMessage(chatId, statusMessage, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            logError('Error handling status command:', error);
            await this.bot.sendMessage(chatId, '❌ Error retrieving status information.');
        }
    }

    async handleUnknown(chatId, command) {
        const message = `
❓ Unknown command: ${command}

Available commands:
/start - Main menu
/signals [pair] - Get trading signal for specific pair
/pairs - View all available trading pairs
/history - Signal history
/subscribe - Enable notifications
/help - Show help

Type /help for detailed information.
        `;

        try {
            await this.bot.sendMessage(chatId, message);
        } catch (error) {
            logError('Error handling unknown command:', error);
        }
    }

    async handlePairs(chatId) {
        try {
            const availablePairs = this.signalGenerator.getAllPairs();
            const trendInfo = this.signalGenerator.getTrendInfo();
            
            let pairsMessage = `📊 *Available Trading Pairs*\n\n`;
            
            // Group pairs by categories
            const majors = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD'];
            const crosses = ['EUR/GBP', 'EUR/JPY', 'GBP/JPY'];
            const commodities = ['XAU/USD', 'XAU/EUR'];
            
            pairsMessage += `🌟 *Major Pairs:*\n`;
            majors.filter(pair => availablePairs.includes(pair)).forEach(pair => {
                const price = this.signalGenerator.getCurrentPrice(pair);
                pairsMessage += `• ${pair}: ${this.formatPairPrice(pair, price)}\n`;
            });
            
            pairsMessage += `\n🔄 *Cross Pairs:*\n`;
            crosses.filter(pair => availablePairs.includes(pair)).forEach(pair => {
                const price = this.signalGenerator.getCurrentPrice(pair);
                pairsMessage += `• ${pair}: ${this.formatPairPrice(pair, price)}\n`;
            });
            
            pairsMessage += `\n🥇 *Commodities:*\n`;
            commodities.filter(pair => availablePairs.includes(pair)).forEach(pair => {
                const price = this.signalGenerator.getCurrentPrice(pair);
                pairsMessage += `• ${pair}: ${this.formatPairPrice(pair, price)}\n`;
            });
            
            pairsMessage += `\n*Usage:*\n`;
            pairsMessage += `• /signals - Random popular pair\n`;
            pairsMessage += `• /signals EUR/USD - Specific pair\n`;
            pairsMessage += `• /signals XAU/USD - Gold signals\n`;
            
            pairsMessage += `\n*Currently active:* ${trendInfo.currentPair}`;

            const keyboard = {
                inline_keyboard: [
                    [
                        { text: '💶 EUR/USD', callback_data: 'signal_EUR/USD' },
                        { text: '💷 GBP/USD', callback_data: 'signal_GBP/USD' }
                    ],
                    [
                        { text: '💴 USD/JPY', callback_data: 'signal_USD/JPY' },
                        { text: '🥇 XAU/USD', callback_data: 'signal_XAU/USD' }
                    ],
                    [
                        { text: '🎲 Random Signal', callback_data: 'get_signal' }
                    ]
                ]
            };

            await this.bot.sendMessage(chatId, pairsMessage, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        } catch (error) {
            logError('Error handling pairs command:', error);
            await this.bot.sendMessage(chatId, '❌ Error retrieving trading pairs.');
        }
    }

    formatPairPrice(pair, price) {
        if (pair.includes('JPY')) {
            return price.toFixed(2);
        } else if (pair.includes('XAU')) {
            return `${price.toFixed(2)} ${pair.split('/')[1]}`;
        } else {
            return price.toFixed(4);
        }
    }

    formatTrend(trend) {
        const trendEmojis = {
            'bullish': '🚀 Bullish',
            'bearish': '📉 Bearish',
            'neutral': '➡️ Neutral'
        };
        return trendEmojis[trend] || '❓ Unknown';
    }

    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        return `${hours}h ${minutes}m`;
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const diffMs = now - timestamp;
        const diffMins = Math.floor(diffMs / 60000);
        
        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours}h ago`;
        
        const diffDays = Math.floor(diffHours / 24);
        return `${diffDays}d ago`;
    }
}

module.exports = Commands;
