const TelegramBot = require('node-telegram-bot-api');
const Commands = require('./commands');
const Scheduler = require('./scheduler');
const { logError, logInfo } = require('./utils');

class Bot {
    constructor() {
        this.token = process.env.TELEGRAM_BOT_TOKEN;
        if (!this.token) {
            throw new Error('TELEGRAM_BOT_TOKEN environment variable is required');
        }
        
        this.bot = new TelegramBot(this.token, { polling: true });
        this.commands = new Commands(this.bot);
        this.scheduler = new Scheduler(this.bot);
        this.subscribers = new Set(); // Store chat IDs of subscribers
        
        this.setupEventHandlers();
    }

    setupEventHandlers() {
        // Handle bot polling errors
        this.bot.on('polling_error', (error) => {
            logError('Polling error:', error);
        });

        // Handle messages
        this.bot.on('message', (msg) => {
            const chatId = msg.chat.id;
            const text = msg.text;

            logInfo(`Received message from ${chatId}: ${text}`);

            // Add user to subscribers when they interact with the bot
            this.subscribers.add(chatId);

            // Handle commands
            if (text && text.startsWith('/')) {
                this.handleCommand(chatId, text, msg);
            }
        });

        // Handle callback queries (inline keyboard buttons)
        this.bot.on('callback_query', (callbackQuery) => {
            const message = callbackQuery.message;
            const data = callbackQuery.data;
            const chatId = message.chat.id;

            this.handleCallbackQuery(chatId, data, callbackQuery);
        });
    }

    handleCommand(chatId, command, msg) {
        const [cmd, ...args] = command.split(' ');
        
        switch (cmd.toLowerCase()) {
            case '/start':
                this.commands.handleStart(chatId, msg);
                break;
            case '/help':
                this.commands.handleHelp(chatId);
                break;
            case '/signals':
                this.commands.handleSignals(chatId, args);
                break;
            case '/pairs':
                this.commands.handlePairs(chatId);
                break;
            case '/history':
                this.commands.handleHistory(chatId);
                break;
            case '/subscribe':
                this.commands.handleSubscribe(chatId);
                break;
            case '/unsubscribe':
                this.commands.handleUnsubscribe(chatId);
                break;
            case '/status':
                this.commands.handleStatus(chatId);
                break;
            default:
                this.commands.handleUnknown(chatId, command);
        }
    }

    handleCallbackQuery(chatId, data, callbackQuery) {
        // Answer the callback query to remove loading state
        this.bot.answerCallbackQuery(callbackQuery.id);

        if (data.startsWith('signal_')) {
            const pair = data.replace('signal_', '');
            this.commands.handleSignals(chatId, [pair]);
        } else {
            switch (data) {
                case 'get_signal':
                    this.commands.handleSignals(chatId);
                    break;
                case 'subscribe':
                    this.commands.handleSubscribe(chatId);
                    break;
                case 'unsubscribe':
                    this.commands.handleUnsubscribe(chatId);
                    break;
                case 'history':
                    this.commands.handleHistory(chatId);
                    break;
                case 'pairs':
                    this.commands.handlePairs(chatId);
                    break;
                case 'help':
                    this.commands.handleHelp(chatId);
                    break;
                default:
                    logError('Unknown callback query data:', data);
            }
        }
    }

    start() {
        logInfo('Bot started successfully');
        
        // Start the scheduler for automated signals
        this.scheduler.start((signal) => {
            this.broadcastSignal(signal);
        });
    }

    stop() {
        if (this.bot) {
            this.bot.stopPolling();
        }
        if (this.scheduler) {
            this.scheduler.stop();
        }
        logInfo('Bot stopped');
    }

    broadcastSignal(signal) {
        const subscribers = Array.from(this.subscribers);
        logInfo(`Broadcasting signal to ${subscribers.length} subscribers`);

        subscribers.forEach(async (chatId) => {
            try {
                await this.commands.sendSignal(chatId, signal);
            } catch (error) {
                logError(`Failed to send signal to ${chatId}:`, error);
                // Remove inactive subscribers
                if (error.response && error.response.statusCode === 403) {
                    this.subscribers.delete(chatId);
                    logInfo(`Removed inactive subscriber: ${chatId}`);
                }
            }
        });
    }

    addSubscriber(chatId) {
        this.subscribers.add(chatId);
    }

    removeSubscriber(chatId) {
        this.subscribers.delete(chatId);
    }

    getSubscriberCount() {
        return this.subscribers.size;
    }
}

module.exports = Bot;
