const express = require('express');
const Bot = require('./bot');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Initialize and start the Telegram bot
const bot = new Bot();
bot.start();

// Start the Express server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    console.log('Telegram bot is starting...');
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('Shutting down gracefully...');
    bot.stop();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('Shutting down gracefully...');
    bot.stop();
    process.exit(0);
});
